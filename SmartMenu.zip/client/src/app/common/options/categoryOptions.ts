export const categoryOptions = [
    {text:'Clean', value:'cleaning table'}
]