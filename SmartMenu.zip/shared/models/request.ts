export interface ChatRequest {
    id:number;
    createdAt: any;
    body:string;
    username:string;
    displayName:string;
    image:string;
}