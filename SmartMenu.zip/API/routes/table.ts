import {Table} from "../../shared/models/table"
